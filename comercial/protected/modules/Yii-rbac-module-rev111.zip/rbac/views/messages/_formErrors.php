<div id="messageError">
<ul>
<?php foreach($messageErrors as $item): ?>
	<li><?php echo $item ?></li>
<?php endforeach ?>
</ul>
</div>