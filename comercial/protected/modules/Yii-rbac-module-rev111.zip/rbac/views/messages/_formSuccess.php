<div id="messageSuccess">
<ul>
<?php foreach($messageSuccess as $item): ?>
	<li><?php echo $item ?></li>
<?php endforeach ?>
</ul>
</div>