<div id="messageInfo">
<ul>
<?php foreach($messageInfos as $item): ?>
	<li><?php echo $item ?></li>
<?php endforeach ?>
</ul>
</div>