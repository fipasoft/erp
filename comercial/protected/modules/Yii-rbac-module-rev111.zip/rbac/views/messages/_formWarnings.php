<div id="messageWarning">
<ul>
<?php foreach($messageWarnings as $item): ?>
	<li><?php echo $item ?></li>
<?php endforeach ?>
</ul>
</div>